"""Unit tests: user-list reading, preflight decisions, run safeguards, verify. No browser, no org."""
import csv
import json
import shutil
import tempfile
import unittest
from argparse import Namespace
from pathlib import Path
from unittest import mock

from helpers import rp


def user(uid, name, active=True, email=None, fed=None, last_login="2026-01-01T00:00:00.000+0000", profile="Standard User"):
    return {"Id": uid, "Username": name, "Name": name.split("@")[0], "Email": email if email is not None else name,
            "IsActive": active, "Profile": {"Name": profile}, "FederationIdentifier": fed, "LastLoginDate": last_login}


class UserListTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_txt(self):
        p = self.tmp / "users.txt"
        p.write_text("username\n# a comment\n a@example.com \n\nb@example.com\n", encoding="utf-8")
        label, rows, blanks = rp.read_user_list(p)
        self.assertEqual([r["username"] for r in rows], ["a@example.com", "b@example.com"])
        self.assertEqual(rows[0]["raw"], " a@example.com ")
        self.assertEqual(blanks, 1)

    def test_csv_with_header_after_title_rows(self):
        p = self.tmp / "users.csv"
        with p.open("w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerows([["Users to reset"], [], ["Id", "Username", "Profile.Name"],
                         ["005A", "a@example.com", "Standard User"], ["", "", ""]])
        _, rows, blanks = rp.read_user_list(p)
        self.assertEqual(rows, [{"row": 4, "raw": "a@example.com", "username": "a@example.com",
                                 "sheet_id": "005A", "sheet_profile": "Standard User"}])
        self.assertEqual(blanks, 1)

    def test_xlsx(self):
        import openpyxl
        p = self.tmp / "users.xlsx"
        wb = openpyxl.Workbook()
        wb.active.append(["Username"])
        wb.active.append(["a@example.com"])
        wb.save(p)
        label, rows, _ = rp.read_user_list(p)
        self.assertIn("users.xlsx", label)
        self.assertEqual(rows[0]["username"], "a@example.com")

    def test_missing_username_column(self):
        p = self.tmp / "bad.csv"
        p.write_text("Email\nx@example.com\n", encoding="utf-8")
        with self.assertRaises(SystemExit):
            rp.read_user_list(p)


class ClassifyTests(unittest.TestCase):
    def test_reasons(self):
        rows = [
            {"row": 2, "raw": "ok@example.com", "username": "ok@example.com", "sheet_id": "", "sheet_profile": ""},
            {"row": 3, "raw": "ok@example.com", "username": "ok@example.com", "sheet_id": "", "sheet_profile": ""},
            {"row": 4, "raw": "gone@example.com", "username": "gone@example.com", "sheet_id": "", "sheet_profile": ""},
            {"row": 5, "raw": "off@example.com", "username": "off@example.com", "sheet_id": "", "sheet_profile": ""},
            {"row": 6, "raw": "frozen@example.com", "username": "frozen@example.com", "sheet_id": "", "sheet_profile": ""},
            {"row": 7, "raw": "me@example.com", "username": "me@example.com", "sheet_id": "", "sheet_profile": ""},
            {"row": 8, "raw": "inv@example.com", "username": "inv@example.com", "sheet_id": "", "sheet_profile": ""},
            {"row": 9, "raw": "id@example.com", "username": "id@example.com", "sheet_id": "005WRONG", "sheet_profile": ""},
            {"row": 10, "raw": "sso@example.com ", "username": "sso@example.com", "sheet_id": "", "sheet_profile": "Old"},
        ]
        users = {u["Username"]: u for u in [
            user("005OK", "ok@example.com"), user("005OFF", "off@example.com", active=False),
            user("005FRZ", "frozen@example.com"), user("005ME", "me@example.com"),
            user("005INV", "inv@example.com", email="inv@example.com.invalid"),
            user("005ID", "id@example.com"), user("005SSO", "sso@example.com", fed="fed-1", last_login=None)]}
        logins = {"005FRZ": {"IsFrozen": True}, "005SSO": {"IsPasswordLocked": True}}
        report, plan = rp.classify(rows, users, logins, "ME@example.com")
        by_row = {r["list_row"]: r for r in report}
        self.assertEqual([u["id"] for u in plan], ["005OK", "005SSO"])
        self.assertIn("duplicate", by_row[3]["reason"])
        self.assertIn("not found", by_row[4]["reason"])
        self.assertIn("inactive", by_row[5]["reason"])
        self.assertIn("frozen", by_row[6]["reason"])
        self.assertIn("own login", by_row[7]["reason"])
        self.assertIn(".invalid", by_row[8]["reason"])
        self.assertIn("not the org's Id", by_row[9]["reason"])
        notes = by_row[10]["notes"]
        for n in ("spaces trimmed", "locked out", "Federation ID", "profile is now", "never logged in"):
            self.assertIn(n, notes)


class PreflightTests(unittest.TestCase):
    def test_preflight_with_mocked_sf(self):
        tmp = Path(tempfile.mkdtemp())
        src = tmp / "users.txt"
        src.write_text("a@example.com\nmissing@example.com\n", encoding="utf-8")

        def fake_sf_json(args):
            if args[:2] == ["org", "display"]:
                self.assertEqual(args[2:], ["-o", "my-sandbox"])
                return {"username": "admin@example.com", "instanceUrl": "https://acme--dev.sandbox.my.salesforce.com/"}
            raise AssertionError(args)

        def fake_soql(org, q):
            self.assertEqual(org, "my-sandbox")
            if "FROM Organization" in q:
                return [{"Id": "00Dfake", "Name": "Example Org", "IsSandbox": True}]
            if "FROM PermissionSetAssignment" in q:
                return [{"PermissionSet": {"Label": "System Administrator"}}]
            if "FROM User " in q:
                return [user("005A", "a@example.com")]
            if "FROM UserLogin" in q:
                return []
            raise AssertionError(q)

        with mock.patch.object(rp, "sf_json", side_effect=fake_sf_json), mock.patch.object(rp, "soql", side_effect=fake_soql):
            rp.cmd_preflight(Namespace(users=str(src), sheet=None, target_org="my-sandbox",
                                       login_url="https://test.salesforce.com", out=str(tmp / "run")))
        plan = json.loads((tmp / "run" / "plan.json").read_text())
        self.assertEqual([u["id"] for u in plan["users"]], ["005A"])
        self.assertEqual(plan["base_url"], "https://acme--dev.sandbox.my.salesforce.com")
        self.assertEqual(plan["login_url"], "https://test.salesforce.com")
        self.assertTrue(plan["is_sandbox"])
        self.assertTrue((tmp / "run" / "preflight.xlsx").is_file())
        shutil.rmtree(tmp, ignore_errors=True)


class RunSafeguardTests(unittest.TestCase):
    """The refusals happen before the browser starts, so they need no Playwright."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def plan(self, sandbox=True, n=3, source=None):
        p = self.tmp / "plan.json"
        data = {"org_alias": "fake", "is_sandbox": sandbox, "base_url": "http://127.0.0.1:9",
                "users": [{"id": f"005U{i}", "username": f"u{i}@example.com"} for i in range(n)]}
        if source:
            data["source_file"] = str(source)
            data["source_sha256"] = "0" * 64
        p.write_text(json.dumps(data))
        return p

    def run_cmd(self, p, **kw):
        a = Namespace(plan=str(p), dry_run=False, limit=None, confirm=None, prod=False, pause=0,
                      login_timeout=1, login_url=None)
        for k, v in kw.items():
            setattr(a, k, v)
        with mock.patch.dict("sys.modules", {"playwright": None, "playwright.sync_api": None}):
            try:
                rp.cmd_run(a)
                return "ran"
            except SystemExit as e:
                return str(e)
            except ImportError:
                return "would start the browser"

    def test_confirm_required(self):
        self.assertIn("--confirm 3", self.run_cmd(self.plan()))
        self.assertIn("--confirm 3", self.run_cmd(self.plan(), confirm=2))
        self.assertEqual(self.run_cmd(self.plan(), confirm=3), "would start the browser")

    def test_limit_changes_the_count(self):
        self.assertIn("--confirm 1", self.run_cmd(self.plan(), limit=1, confirm=3))

    def test_production_needs_prod_flag(self):
        self.assertIn("PRODUCTION", self.run_cmd(self.plan(sandbox=False), confirm=3))
        self.assertEqual(self.run_cmd(self.plan(sandbox=False), confirm=3, prod=True), "would start the browser")

    def test_dry_run_needs_no_confirm(self):
        self.assertEqual(self.run_cmd(self.plan(), dry_run=True), "would start the browser")

    def test_changed_source_file_refuses(self):
        src = self.tmp / "users.txt"
        src.write_text("u0@example.com\n")
        self.assertIn("has changed since the preflight", self.run_cmd(self.plan(source=src), confirm=3))

    def test_already_reset_users_are_excluded(self):
        p = self.plan()
        with p.with_name("results.csv").open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=rp.RESULT_FIELDS)
            w.writeheader()
            w.writerow({"time_utc": "2026-01-01T00:00:00+00:00", "user_id": "005U0", "username": "u0@example.com",
                        "status": "RESET", "message": "", "screenshot": ""})
        self.assertIn("--confirm 2", self.run_cmd(p, confirm=3))

    def test_bad_results_header_refuses(self):
        p = self.plan()
        p.with_name("results.csv").write_text("something,else\n")
        self.assertIn("expected header", self.run_cmd(p, confirm=3))


class HelperTests(unittest.TestCase):
    def test_ui_hosts(self):
        self.assertEqual(rp.ui_hosts("https://acme.my.salesforce.com"),
                         {"acme.my.salesforce.com", "acme.lightning.force.com", "acme.my.salesforce-setup.com"})
        self.assertIn("acme--dev.sandbox.lightning.force.com", rp.ui_hosts("https://acme--dev.sandbox.my.salesforce.com"))
        self.assertEqual(rp.ui_hosts("http://127.0.0.1:8000"), {"127.0.0.1:8000"})

    def test_bare_strips_tokens(self):
        self.assertEqual(rp.bare("https://x/secur/frontdoor.jsp?sid=SECRET#frag"), "https://x/secur/frontdoor.jsp")

    def test_verdicts(self):
        plan = {"users": [{"id": "005AAAAAAAAAAAAAAA", "username": "a"}, {"id": "005BBBBBBBBBBBBBBB", "username": "b"},
                          {"id": "005CCCCCCCCCCCCCCC", "username": "c"}]}
        results = [{"user_id": "005AAAAAAAAAAAAAAA", "status": "RESET", "message": ""},
                   {"user_id": "005BBBBBBBBBBBBBBB", "status": "RESET", "message": ""}]
        audit = [{"CreatedDate": "t1", "Display": "Reset password for user ... UserID: [005AAAAAAAAAAAA]",
                  "CreatedBy": {"Username": "admin"}},
                 {"CreatedDate": "t2", "Display": "UserID: [005ZZZZZZZZZZZZ]", "CreatedBy": {"Username": "admin"}}]
        rows, c, extra = rp.verdicts(plan, results, audit)
        self.assertEqual([r[-1] for r in rows], ["OK", "SCRIPT SAID RESET, NOT IN AUDIT", "NOT RESET"])
        self.assertEqual(len(extra), 1)

    def test_help_parses(self):
        with self.assertRaises(SystemExit) as cm:
            rp.build_parser().parse_args(["--help"])
        self.assertEqual(cm.exception.code, 0)
