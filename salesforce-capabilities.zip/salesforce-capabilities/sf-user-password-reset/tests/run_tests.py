"""Run all offline tests. No Salesforce org is called.

    python tests/run_tests.py            unit tests + browser tests (browser tests skip without Playwright)
    python tests/run_tests.py --unit     unit tests only (fast, no browser)
"""
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

if __name__ == "__main__":
    pattern = "test_unit.py" if "--unit" in sys.argv else "test_*.py"
    suite = unittest.defaultTestLoader.discover(str(HERE), pattern=pattern, top_level_dir=str(HERE))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
