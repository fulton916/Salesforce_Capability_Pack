"""Browser tests: `run` against a fake classic Setup user page served on localhost.

Needs Playwright and its Chromium (`python -m playwright install chromium`); skipped otherwise.
No Salesforce org is touched.
"""
import html
import json
import shutil
import tempfile
import threading
import time
import unittest
from argparse import Namespace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from helpers import rp

try:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as _p:
        _b = _p.chromium.launch(headless=True)
        _b.close()
    HAVE_BROWSER = True
except Exception:  # not installed, or no browser binary
    HAVE_BROWSER = False

USERS = {  # id -> (username shown on page, confirm text or None for no button)
    "005GOOD1": ("good1@example.com", rp.DIALOG_TEXT), "005GOOD2": ("good2@example.com", rp.DIALOG_TEXT),
    "005GOOD3": ("good3@example.com", rp.DIALOG_TEXT), "005GOOD4": ("good4@example.com", rp.DIALOG_TEXT),
    "005GOOD5": ("good5@example.com", rp.DIALOG_TEXT),
    "005MISM1": ("someone.else@example.com", rp.DIALOG_TEXT),  # page shows another user
    "005DLG01": ("dlg@example.com", "Delete this user?"),         # unexpected confirmation text
    "005NOBTN": ("nobtn@example.com", None),                      # no Reset Password button
}
RESETS = []
LOGIN_MODE = {"mode": "instant"}   # instant | delayed (same tab, 4 s later) | newtab (login finishes in a 2nd tab)
LOGIN_FORM = '<form><input id="username"><input id="Login" type="submit" value="Log In"></form>'


class FakeOrg(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, body, code=200, loc=None):
        self.send_response(code)
        if loc:
            self.send_header("Location", loc)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode())

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/":
            m = LOGIN_MODE["mode"]
            if m == "instant":
                return self.send("", 302, "/lightning/page/home")
            go = ("location.href='/lightning/page/home'" if m == "delayed"
                  else "window.open('/lightning/page/home'); document.title='still login'")
            return self.send(LOGIN_FORM + f"<script>setTimeout(() => {{ {go} }}, 4000)</script>")
        if path.startswith("/lightning/"):
            return self.send("<h1>Home</h1>")
        if path == "/login":
            return self.send(LOGIN_FORM)
        if path.startswith("/reset/"):
            RESETS.append(path[7:])
            return self.send("<p>A new password for the following user has been sent via email. "
                             "The user will be required to enter a new password upon initial login.</p>")
        uid = path[1:]
        if uid == "005LOST1":
            return self.send("", 302, "/login?ec=302")
        if uid in USERS:
            name, dlg = USERS[uid]
            btn = (f'<input type="button" class="btn" value=" Reset Password " '
                   f'onclick="if(confirm({html.escape(json.dumps(dlg))})) location.href=\'/reset/{uid}\'">') if dlg else ""
            return self.send(f'<input type="button" class="btn" value=" Edit "> {btn}<table>'
                             f'<tr><td class="labelCol">Name</td><td class="dataCol">X</td></tr>'
                             f'<tr><td class="labelCol">Username</td><td class="dataCol">{name}</td></tr></table>')
        self.send("not found", 404)


@unittest.skipUnless(HAVE_BROWSER, "Playwright/Chromium not installed")
class BrowserRunTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), FakeOrg)
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.tmp = Path(tempfile.mkdtemp())
        cls.saved = (rp.PROFILE_DIR, rp.launch, rp.find_button_frame)
        rp.PROFILE_DIR = cls.tmp / "profile"
        real_launch, real_find = rp.launch, rp.find_button_frame
        rp.launch = lambda p, headless=True: real_launch(p, headless=True)
        rp.find_button_frame = lambda page, t: real_find(page, 3)   # don't wait 45 s on the no-button case

    @classmethod
    def tearDownClass(cls):
        rp.PROFILE_DIR, rp.launch, rp.find_button_frame = cls.saved
        cls.srv.shutdown()
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def setUp(self):
        RESETS.clear()
        LOGIN_MODE["mode"] = "instant"

    def plan(self, ids, name, sandbox=True):
        d = self.tmp / name
        d.mkdir(exist_ok=True)
        p = d / "plan.json"
        users = [{"id": i, "username": "mism@example.com" if i == "005MISM1" else USERS.get(i, ("lost@example.com",))[0]}
                 for i in ids]
        p.write_text(json.dumps({"org_alias": "fake", "is_sandbox": sandbox, "base_url": self.base, "users": users}))
        return p

    def run_cmd(self, p, **kw):
        a = Namespace(plan=str(p), dry_run=False, limit=None, confirm=None, prod=False, pause=0, login_timeout=4,
                      login_url=None)
        for k, v in kw.items():
            setattr(a, k, v)
        try:
            rp.cmd_run(a)
            return "ok"
        except SystemExit as e:
            return f"exit: {e}"

    def results(self, p, dry=False):
        return {r["user_id"]: r["status"]
                for r in rp.read_results(p.with_name("results_dryrun.csv" if dry else "results.csv"))}

    def test_dry_run_clicks_nothing(self):
        p = self.plan(["005GOOD1", "005MISM1", "005GOOD2"], "dry")
        self.run_cmd(p, dry_run=True)
        self.assertEqual(RESETS, [])
        self.assertEqual(self.results(p, dry=True), {"005GOOD1": "DRY-OK", "005MISM1": "FAILED", "005GOOD2": "DRY-OK"})

    def test_resets_good_users_skips_bad_pages_and_resumes(self):
        p = self.plan(["005GOOD1", "005MISM1", "005GOOD2", "005DLG01", "005GOOD3"], "main")
        self.run_cmd(p, confirm=5)
        self.assertEqual(RESETS, ["005GOOD1", "005GOOD2", "005GOOD3"])
        self.assertEqual(self.results(p), {"005GOOD1": "RESET", "005MISM1": "FAILED", "005GOOD2": "RESET",
                                           "005DLG01": "FAILED", "005GOOD3": "RESET"})
        self.assertEqual(len(list((p.parent / "screenshots").glob("005GOOD*.png"))), 3)
        self.assertIn("--confirm 2", self.run_cmd(p, confirm=5))   # resume: already-reset users excluded
        self.run_cmd(p, confirm=2)
        self.assertEqual(RESETS, ["005GOOD1", "005GOOD2", "005GOOD3"])   # nobody reset twice

    def test_stops_after_three_failures_in_a_row(self):
        p = self.plan(["005MISM1", "005NOBTN", "005DLG01", "005GOOD4"], "fails")
        self.run_cmd(p, confirm=4)
        self.assertEqual(RESETS, [])
        self.assertNotIn("005GOOD4", self.results(p))

    def test_limit_one(self):
        p = self.plan(["005GOOD4", "005GOOD5"], "limit")
        self.run_cmd(p, confirm=1, limit=1)
        self.assertEqual(RESETS, ["005GOOD4"])

    def test_session_lost_without_relogin(self):
        p = self.plan(["005LOST1", "005GOOD5"], "lost")
        self.run_cmd(p, confirm=2)
        self.assertEqual(self.results(p).get("005LOST1"), "FAILED")
        self.assertNotIn("005LOST1", RESETS)

    def test_login_detected_when_it_completes_later(self):
        for mode in ("delayed", "newtab"):
            with self.subTest(mode=mode):
                LOGIN_MODE["mode"] = mode
                RESETS.clear()
                p = self.plan(["005GOOD5"], f"login_{mode}")
                t0 = time.time()
                self.run_cmd(p, confirm=1, login_timeout=30)
                self.assertEqual(RESETS, ["005GOOD5"], f"after {time.time() - t0:.0f} s")
                self.assertEqual(self.results(p).get("005GOOD5"), "RESET")

    def test_login_url_override_is_used(self):
        p = self.plan(["005GOOD1"], "login_url")
        self.run_cmd(p, confirm=1, login_url=self.base + "/lightning/page/home")
        self.assertEqual(RESETS, ["005GOOD1"])

    def test_empty_results_file_gets_header(self):
        p = self.plan(["005GOOD1"], "empty")
        p.with_name("results.csv").write_text("")      # left behind by an interrupted run
        self.run_cmd(p, confirm=1)
        first = p.with_name("results.csv").read_text().splitlines()[0]
        self.assertEqual(first, ",".join(rp.RESULT_FIELDS))
        self.assertEqual(self.results(p), {"005GOOD1": "RESET"})
