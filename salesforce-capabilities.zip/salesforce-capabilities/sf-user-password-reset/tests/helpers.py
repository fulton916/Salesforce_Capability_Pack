"""Loads scripts/reset_passwords.py as module `rp` for the tests."""
import importlib.util
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "reset_passwords.py"
_spec = importlib.util.spec_from_file_location("reset_passwords", SCRIPT)
rp = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(rp)
