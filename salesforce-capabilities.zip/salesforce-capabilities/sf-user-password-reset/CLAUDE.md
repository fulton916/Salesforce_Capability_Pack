# CLAUDE.md — sf-user-password-reset

## What this is

`scripts/reset_passwords.py` resets Salesforce user passwords by clicking **Reset Password** in
the classic Setup user page with Playwright, one user at a time. Salesforce emails each user.
Commands: `preflight` (read-only), `run` (the only write), `verify` (read-only, Setup Audit
Trail), `open-browser`.

## When to use it

The user asks to reset passwords (send reset emails) for a list of users, and wants a record of
it. Not for: setting a specific password, SSO-only users, or a single user (use Setup by hand).

## Workflow (in this order; do not skip steps)

1. Get the user-list file, the org alias, and whether the org is production. Ask for the login
   URL only if My Domain login does not work for them (`https://test.salesforce.com` for
   sandboxes, `https://login.salesforce.com` for production).
2. Check the CLI login: `sf org display --target-org <alias> --json`.
3. Preflight:
   ```
   python scripts/reset_passwords.py preflight --users <file> --target-org <alias> --out runs/<name> [--login-url <url>]
   ```
   Report READY / SKIP counts, every SKIP reason, the notes, and the "Reset User Passwords"
   line. If it says NOTHING, stop: the run would fail.
4. Ask the user to review `runs/<name>/preflight.xlsx` and approve the READY list.
5. Dry run (clicks nothing; the user logs in in the browser window):
   ```
   python scripts/reset_passwords.py run --plan runs/<name>/plan.json --dry-run
   ```
   Every row in `results_dryrun.csv` should be `DRY-OK`. Investigate any FAILED before going on.
6. Pilot, only after the user says go: `run --plan ... --limit 1 --confirm 1` (add `--prod` for
   production). Ask the user to confirm the email arrived.
7. Full run, only after the user says go: `run --plan ... --confirm <N>` where N is the number the
   script says remains. Add `--prod` only for production and only with explicit approval.
8. Verify:
   ```
   python scripts/reset_passwords.py verify --plan runs/<name>/plan.json
   ```
   Report the verdict counts and any "Resets not in plan".

## Inputs and outputs

| Command | Input | Output (in the plan folder) |
|---|---|---|
| `preflight` | user list (`.xlsx`/`.csv` with `Username` column, or `.txt`), org | `plan.json`, `preflight.xlsx` (Summary / READY / SKIP) |
| `run` | `plan.json` | `results.csv` (or `results_dryrun.csv`), `screenshots/*.png` |
| `verify` | `plan.json`, `results.csv` | `verify.xlsx` (Verify / Resets not in plan) |

`results.csv` columns: `time_utc, user_id, username, status, message, screenshot`. Status is
`RESET`, `DRY-OK` or `FAILED`.

## Guardrails

- Never run `run` without `--dry-run` unless the user has approved this exact plan and count.
- Never pass `--prod` on your own initiative. Production needs the user's explicit go-ahead in
  this conversation.
- Never compute `--confirm` from anything but the number the script prints ("re-run with
  --confirm N"). Never loop or script around the confirm check.
- Never edit `plan.json` or the user-list file to add users. Re-run preflight instead (the file
  hash check exists to catch exactly this).
- Never remove or weaken a safeguard: username check, dialog-text check, 3-failure stop,
  confirm count, `--prod`, source hash, resume logic.
- Do not delete `results.csv`: it is what prevents a second reset of the same user.
- Do not read or print the browser profile folder (it holds session cookies). Do not log full
  URLs (`bare()` strips query strings for that reason).
- Do not commit `runs/` (usernames, emails, screenshots).

## Verify success

- `results.csv`: every planned user `RESET`.
- `verify.xlsx`: every row `OK`. `SCRIPT SAID RESET, NOT IN AUDIT` needs a look in Setup;
  `IN AUDIT ONLY` means someone else reset that user in the window.

## Tests

```
python tests/run_tests.py          # 25 tests; 8 browser tests need Playwright + Chromium, else skipped
python tests/run_tests.py --unit   # 17 unit tests, no browser
```
Run them after any change to the script.

## Known pitfalls

- The login wait accepts a login that finishes in another tab; it polls with Playwright's
  `wait_for_timeout`, never `time.sleep` (Playwright only sees new pages during its own calls).
- "Reset Password button not found": the running user lacks the permission, the page language
  is not English, or the user is a portal/SSO user without that button.
- `--confirm` mismatch after a partial run is expected: already-reset users are excluded.
- `results.csv does not start with the expected header row`: the file was hand-edited. Restore
  the header `time_utc,user_id,username,status,message,screenshot`.
- The audit trail can lag a minute; run `verify` again if a fresh reset is missing.
