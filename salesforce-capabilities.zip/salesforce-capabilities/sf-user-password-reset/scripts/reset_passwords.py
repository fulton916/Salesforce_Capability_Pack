#!/usr/bin/env python3
"""Reset Salesforce user passwords through the Setup UI, one user at a time.

  preflight     read-only. Reads the user list, checks every user in the org, writes the plan.
  run           opens a browser, waits for you to log in, then clicks Reset Password for each
                user in the plan. --dry-run opens each page and checks it without clicking.
  verify        read-only. Matches the run's results against the org's Setup Audit Trail.
  open-browser  opens the browser profile the script uses, at a login page.

Nothing is reset except by `run`, and `run` will not start unless --confirm equals the number
of users it is about to reset. A plan for a production org also needs --prod.

Why the Setup UI: "Reset Password" in Setup sends Salesforce's own reset email and is what an
admin would click by hand. The script only automates the clicking, with checks on every page.

  python reset_passwords.py preflight --users users.xlsx --target-org my-sandbox --out runs/reset1
  python reset_passwords.py run --plan runs/reset1/plan.json --dry-run
  python reset_passwords.py run --plan runs/reset1/plan.json --limit 2 --confirm 2
  python reset_passwords.py run --plan runs/reset1/plan.json --confirm <N>   (add --prod for production)
  python reset_passwords.py verify --plan runs/reset1/plan.json
"""
import argparse
import csv
import datetime as dt
import hashlib
import json
import re
import shutil
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse

DEFAULT_PROFILE_DIR = Path.home() / ".sf-password-reset-browser"
PROFILE_DIR = DEFAULT_PROFILE_DIR          # set from --profile-dir at start-up
DIALOG_TEXT = "Reset password for this user?"
SUCCESS_RE = re.compile(r"A new password for the following user has been sent via email", re.I)
RESULT_FIELDS = ["time_utc", "user_id", "username", "status", "message", "screenshot"]
MAX_CONSECUTIVE_FAILURES = 3


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def utcnow():
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0)


# ---------------------------------------------------------------- sf CLI (reads only)

def sf_json(args):
    exe = shutil.which("sf")
    if not exe:
        sys.exit("sf CLI not found on PATH")
    p = subprocess.run([exe, *args, "--json"], capture_output=True)
    out = p.stdout.decode("utf-8-sig", "replace")
    if "{" not in out:
        sys.exit(f"sf {' '.join(args[:2])} returned no JSON: {p.stderr.decode(errors='replace')[:300]}")
    data = json.loads(out[out.index("{"):])
    if data.get("status") != 0:
        sys.exit(f"sf {' '.join(args[:2])} failed: {data.get('message')}")
    return data["result"]


def org_args(org):
    return ["-o", org] if org else []


def soql(org, query):
    return sf_json(["data", "query", *org_args(org), "-q", query])["records"]


def quote_list(values):
    return ",".join("'" + v.replace("\\", "\\\\").replace("'", "\\'") + "'" for v in values)


def chunks(seq, n=100):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


# ---------------------------------------------------------------- user list

def _rows_from_table(rows, label):
    """Find the header row holding 'Username'; return [{row, raw, username, sheet_id, sheet_profile}]."""
    for hi, r in enumerate(rows):
        names = [str(c).strip().lower() if c is not None else "" for c in r]
        if "username" in names:
            break
    else:
        sys.exit(f"no 'Username' column header in {label}")
    ucol = names.index("username")
    icol = names.index("id") if "id" in names else None
    pcol = names.index("profile.name") if "profile.name" in names else (
        names.index("profile") if "profile" in names else None)
    out, blanks = [], 0
    for n, r in enumerate(rows[hi + 1:], start=hi + 2):
        def cell(c):
            return str(r[c]) if c is not None and c < len(r) and r[c] is not None else ""
        if not cell(ucol).strip():
            blanks += 1
            continue
        out.append({"row": n, "raw": cell(ucol), "username": cell(ucol).strip(),
                    "sheet_id": cell(icol).strip(), "sheet_profile": cell(pcol).strip()})
    return out, blanks


def read_user_list(path, sheet=None):
    """Read usernames from .xlsx/.xlsm (a 'Username' column), .csv (same) or .txt (one per line).

    Optional columns: 'Id' (must match the org's user Id) and 'Profile.Name' / 'Profile'
    (a note is added if the org's profile differs). Returns (label, rows, blank_count).
    """
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        ws = wb[sheet] if sheet else wb.worksheets[0]
        rows, blanks = _rows_from_table(list(ws.iter_rows(values_only=True)), f"sheet {ws.title!r}")
        return f"{path.name} [{ws.title}]", rows, blanks
    if suffix == ".csv":
        with path.open(newline="", encoding="utf-8-sig") as fh:
            rows, blanks = _rows_from_table(list(csv.reader(fh)), path.name)
        return path.name, rows, blanks
    rows, blanks = [], 0
    for n, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), start=1):
        if not line.strip():
            blanks += 1
            continue
        if line.strip().startswith("#") or (n == 1 and line.strip().lower() == "username"):
            continue
        rows.append({"row": n, "raw": line, "username": line.strip(), "sheet_id": "", "sheet_profile": ""})
    return path.name, rows, blanks


# ---------------------------------------------------------------- preflight

def classify(rows, users, logins, running_user):
    """Decide READY / SKIP for every list row. Pure function: no org calls.

    users: {lower(username): User record}; logins: {UserId: UserLogin record}.
    Returns (report rows, plan users).
    """
    email_count = Counter((u.get("Email") or "").lower() for u in users.values())
    seen, plan_users, report = {}, [], []
    for r in rows:
        key = r["username"].lower()
        u = users.get(key)
        skip, notes = [], []
        if r["raw"] != r["username"]:
            notes.append("spaces trimmed from the list value")
        if key in seen:
            skip.append(f"duplicate of list row {seen[key]}")
        seen.setdefault(key, r["row"])
        if not u:
            skip.append("username not found in the org")
        else:
            lg = logins.get(u["Id"], {})
            email = (u.get("Email") or "").strip()
            if r["sheet_id"] and r["sheet_id"][:15] != u["Id"][:15]:
                skip.append(f"list Id {r['sheet_id']} is not the org's Id {u['Id']}")
            if not u["IsActive"]:
                skip.append("inactive")
            if lg.get("IsFrozen"):
                skip.append("frozen")
            if u["Username"].lower() == running_user.lower():
                skip.append("this is your own login")
            if not email or email.lower().endswith(".invalid"):
                skip.append(f"email {email or '(blank)'} will not receive the reset")
            if lg.get("IsPasswordLocked"):
                notes.append("currently locked out")
            if u.get("FederationIdentifier"):
                notes.append("has a Federation ID (SSO)")
            profile = (u.get("Profile") or {}).get("Name")
            if r["sheet_profile"] and r["sheet_profile"] != profile:
                notes.append(f"profile is now {profile}")
            if email_count[email.lower()] > 1:
                notes.append(f"email shared by {email_count[email.lower()]} users in this list")
            if not u.get("LastLoginDate"):
                notes.append("has never logged in")
        status = "SKIP" if skip else "READY"
        report.append({"list_row": r["row"], "username": r["username"], "status": status,
                       "reason": "; ".join(skip), "notes": "; ".join(notes),
                       "user_id": u["Id"] if u else "", "name": u["Name"] if u else "",
                       "email": u.get("Email") if u else "", "profile": (u.get("Profile") or {}).get("Name") if u else "",
                       "last_login": (u.get("LastLoginDate") or "")[:10] if u else ""})
        if status == "READY":
            plan_users.append({"id": u["Id"], "username": u["Username"], "name": u["Name"], "email": u.get("Email")})
    return report, plan_users


def cmd_preflight(a):
    out_dir = Path(a.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    src = Path(a.users)
    label, rows, blanks = read_user_list(src, a.sheet)
    log(f"{len(rows)} usernames read from {label} ({blanks} blank rows ignored)")

    org = sf_json(["org", "display", *org_args(a.target_org)])
    running_user = org["username"]
    base_url = org["instanceUrl"].rstrip("/")
    o = soql(a.target_org, "SELECT Id, Name, IsSandbox FROM Organization")[0]
    alias = a.target_org or org.get("alias") or running_user
    log(f"org {alias}: {o['Name']} {o['Id']} sandbox={o['IsSandbox']} url={base_url} you={running_user}")

    perms = soql(a.target_org, "SELECT PermissionSet.Label FROM PermissionSetAssignment WHERE Assignee.Username = "
                               f"{quote_list([running_user])} AND PermissionSet.PermissionsResetPasswords = true")
    perm_labels = sorted({p["PermissionSet"]["Label"] for p in perms})
    log(f"'Reset User Passwords' held by {running_user} via: {perm_labels or 'NOTHING'}")

    names = sorted({r["username"].lower() for r in rows})
    users = {}
    for c in chunks(names):
        for u in soql(a.target_org, "SELECT Id, Username, Name, Email, IsActive, Profile.Name, UserType, "
                                    "FederationIdentifier, LastLoginDate FROM User WHERE Username IN (" + quote_list(c) + ")"):
            users[u["Username"].lower()] = u
    ids = [u["Id"] for u in users.values()]
    logins = {}
    for c in chunks(ids):
        for lg in soql(a.target_org, "SELECT UserId, IsFrozen, IsPasswordLocked FROM UserLogin WHERE UserId IN ("
                                     + quote_list(c) + ")"):
            logins[lg["UserId"]] = lg

    report, plan_users = classify(rows, users, logins, running_user)
    plan = {"created_utc": utcnow().isoformat(), "org_alias": alias, "org_id": o["Id"], "org_name": o["Name"],
            "is_sandbox": o["IsSandbox"], "base_url": base_url, "login_url": a.login_url or "",
            "running_user": running_user, "running_user_has_reset_permission": bool(perm_labels),
            "source_file": str(src.resolve()), "source_sha256": hashlib.sha256(src.read_bytes()).hexdigest(),
            "users": plan_users}
    (out_dir / "plan.json").write_text(json.dumps(plan, indent=2), encoding="utf-8")
    write_xlsx(out_dir / "preflight.xlsx", report, plan, perm_labels)

    c = Counter(x["status"] for x in report)
    log(f"READY {c['READY']}   SKIP {c['SKIP']}   -> {out_dir / 'preflight.xlsx'}")
    for x in report:
        if x["status"] == "SKIP":
            log(f"  SKIP row {x['list_row']} {x['username']}: {x['reason']}")
    for note, n in Counter(n for x in report for n in x["notes"].split("; ") if n).most_common():
        log(f"  note x{n}: {note}")
    if not perm_labels:
        log(f"WARNING: {running_user} does not hold 'Reset User Passwords' in {alias}")


def write_xlsx(path, report, plan, perm_labels):
    import openpyxl
    from openpyxl.styles import Font, PatternFill
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Summary"
    c = Counter(x["status"] for x in report)
    for k, v in [("Org", f"{plan['org_alias']} - {plan['org_name']} {plan['org_id']}"),
                 ("Production", "YES" if not plan["is_sandbox"] else "no (sandbox)"),
                 ("URL", plan["base_url"]), ("Login URL", plan.get("login_url") or "(org URL)"),
                 ("Run as", plan["running_user"]),
                 ("Reset User Passwords via", ", ".join(perm_labels) or "NOT HELD"),
                 ("Source", plan["source_file"]), ("Source SHA-256", plan["source_sha256"]),
                 ("Checked (UTC)", plan["created_utc"]),
                 ("Rows in the list", len(report)), ("READY - will be reset", c["READY"]),
                 ("SKIP - will not be reset", c["SKIP"])]:
        ws.append([k, v])
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 90
    for status in ("READY", "SKIP"):
        s = wb.create_sheet(status)
        cols = list(report[0].keys()) if report else []
        s.append(cols)
        for cell in s[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="1F4E78" if status == "READY" else "C00000")
        for x in report:
            if x["status"] == status:
                s.append([x[k] for k in cols])
        for col, w in zip("ABCDEFGHIJK", (10, 45, 9, 45, 45, 20, 30, 38, 32, 12)):
            s.column_dimensions[col].width = w
        s.freeze_panes = "A2"
    wb.save(path)


# ---------------------------------------------------------------- browser helpers

def ui_hosts(base_url):
    """Hosts that count as 'logged in to this org' (My Domain, Lightning, Setup domains)."""
    host = urlparse(base_url).netloc
    if host.endswith(".my.salesforce.com"):
        prefix = host[: -len(".my.salesforce.com")]
        return {host, prefix + ".lightning.force.com", prefix + ".my.salesforce-setup.com"}
    return {host}


def bare(url):
    """URL without query/fragment, so session tokens never reach the log."""
    return url.split("?")[0].split("#")[0]


def logged_in(page, hosts):
    u = urlparse(page.url)
    if u.netloc not in hosts or "ec=302" in u.query:
        return False
    if u.path.startswith(("/login", "/secur/", "/_ui/identity/", "/setup/secur/")) or u.path in ("", "/"):
        return False
    return page.locator("#Login, input[name=Login]").count() == 0


def wait_for_login(ctx, hosts, timeout_s):
    """Wait until any open tab is on a logged-in Salesforce page; return that tab.
    Waits with wait_for_timeout, never time.sleep: Playwright only receives page
    updates (new URLs, new tabs) while one of its own calls is running."""
    log(f"Waiting for you to log in in the browser window (up to {max(timeout_s // 60, 1)} min)...")
    end, last_report = time.time() + timeout_s, 0.0
    while time.time() < end:
        pages = [pg for pg in ctx.pages if not pg.is_closed()]
        for pg in pages:
            try:
                if logged_in(pg, hosts):
                    log(f"Logged in: {bare(pg.url)}")
                    pg.bring_to_front()
                    return pg
            except Exception:
                pass
        if time.time() - last_report > 20:
            log("  tabs: " + (" | ".join(bare(pg.url)[:90] for pg in pages) or "none open"))
            last_report = time.time()
        (pages[0].wait_for_timeout(2000) if pages else time.sleep(2))
    return None


def on_login_page(page):
    u = urlparse(page.url)
    return "ec=302" in u.query or "/login" in u.path or page.locator("#Login, input[name=Login]").count() > 0


def find_button_frame(page, timeout_s):
    end = time.time() + timeout_s
    while time.time() < end:
        for f in page.frames:
            try:
                if f.get_by_role("button", name="Reset Password", exact=True).count():
                    return f
            except Exception:
                pass
        if on_login_page(page):
            return None
        page.wait_for_timeout(1000)
    return None


class SessionLost(Exception):
    pass


def reset_one(page, base, u, dry, shots):
    """Open the user's classic Setup page, check the username shown, click Reset Password,
    accept only the expected confirmation, and wait for Salesforce's success message."""
    page.goto(f"{base}/{u['id']}?noredirect=1&isUserEntityOverride=1", wait_until="domcontentloaded")
    f = find_button_frame(page, 45)
    if f is None:
        if on_login_page(page):
            raise SessionLost()
        raise RuntimeError("Reset Password button not found on the user page")
    cell = f.locator("xpath=//td[normalize-space()='Username']/following-sibling::td[1]").first
    shown = cell.inner_text(timeout=5000).strip() if cell.count() else ""
    if shown.lower() != u["username"].lower():
        raise RuntimeError(f"page shows username {shown!r}, expected {u['username']!r} - not clicked")
    if dry:
        return "DRY-OK", "page and button checked, not clicked", ""

    seen = []

    def on_dialog(d):
        seen.append(d.message)
        try:
            d.accept() if d.message.strip() == DIALOG_TEXT else d.dismiss()
        except Exception as e:
            seen.append(f"(dialog handling failed: {e})")

    page.once("dialog", on_dialog)
    f.get_by_role("button", name="Reset Password", exact=True).first.click()
    end = time.time() + 30
    while time.time() < end:
        if seen and seen[0].strip() != DIALOG_TEXT:
            raise RuntimeError(f"unexpected confirmation {seen[0]!r} - dismissed, not reset")
        for fr in page.frames:
            try:
                t = fr.locator("body").inner_text(timeout=2000)
            except Exception:
                continue
            if SUCCESS_RE.search(t):
                shot = shots / f"{u['id']}_{re.sub(r'[^A-Za-z0-9._@-]', '_', u['username'])}.png"
                page.screenshot(path=str(shot))
                line = next(ln.strip() for ln in t.splitlines() if SUCCESS_RE.search(ln))
                return "RESET", line, shot.name
        page.wait_for_timeout(1000)
    if not seen:
        raise RuntimeError("no confirmation prompt appeared after clicking - state unknown, check the audit trail")
    raise RuntimeError("confirmed, but no success message within 30 s - state unknown, check the audit trail")


def launch(p, headless=False):
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    ctx = p.chromium.launch_persistent_context(str(PROFILE_DIR), headless=headless,
                                               viewport={"width": 1400, "height": 900})
    return ctx, (ctx.pages[0] if ctx.pages else ctx.new_page())


# ---------------------------------------------------------------- run

def read_results(path):
    if not path.exists() or path.stat().st_size == 0:
        return []
    with path.open(newline="", encoding="utf-8") as fh:
        rd = csv.DictReader(fh)
        if rd.fieldnames != RESULT_FIELDS:
            sys.exit(f"{path} does not start with the expected header row - fix it before running again")
        return list(rd)


def cmd_run(a):
    plan_path = Path(a.plan)
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    src = Path(plan.get("source_file", ""))
    if plan.get("source_sha256") and src.is_file() and hashlib.sha256(src.read_bytes()).hexdigest() != plan["source_sha256"]:
        sys.exit(f"{src.name} has changed since the preflight. Re-run preflight so the plan matches the list.")
    results_path = plan_path.with_name("results_dryrun.csv" if a.dry_run else "results.csv")
    done = {r["user_id"] for r in read_results(plan_path.with_name("results.csv")) if r["status"] == "RESET"}
    todo = [u for u in plan["users"] if u["id"] not in done]
    if a.limit:
        todo = todo[: a.limit]
    log(f"plan: {plan['org_alias']} ({'PRODUCTION' if not plan['is_sandbox'] else 'sandbox'}) {plan['base_url']}")
    log(f"{len(plan['users'])} users in plan, {len(done)} already reset, {len(todo)} in this run"
        + (" (DRY RUN - nothing will be clicked)" if a.dry_run else ""))
    if not todo:
        return
    if not a.dry_run:
        if not plan["is_sandbox"] and not a.prod:
            sys.exit("This plan targets a PRODUCTION org. Add --prod once the reset is approved.")
        if a.confirm != len(todo):
            sys.exit(f"Not started. This run would reset {len(todo)} users; re-run with --confirm {len(todo)}.")

    from playwright.sync_api import sync_playwright
    shots = plan_path.parent / "screenshots"
    shots.mkdir(exist_ok=True)
    new_file = not results_path.exists() or results_path.stat().st_size == 0
    hosts = ui_hosts(plan["base_url"])
    login_url = a.login_url or plan.get("login_url") or plan["base_url"]
    counts, fails_in_a_row, started = Counter(), 0, time.time()
    with sync_playwright() as p, results_path.open("a", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=RESULT_FIELDS)
        if new_file:
            w.writeheader()
            fh.flush()
        ctx, page = launch(p)
        page.goto(login_url)
        page = wait_for_login(ctx, hosts, a.login_timeout)
        if page is None:
            sys.exit("No login - nothing done.")
        for i, u in enumerate(todo, 1):
            log(f"[{i}/{len(todo)}] {u['username']} ({u['id']})")
            for attempt in (1, 2):
                try:
                    status, msg, shot = reset_one(page, plan["base_url"], u, a.dry_run, shots)
                    break
                except SessionLost:
                    log("  session ended - log in again in the browser window")
                    page.goto(login_url)
                    pg = None if attempt == 2 else wait_for_login(ctx, hosts, a.login_timeout)
                    if pg is None:
                        status, msg, shot = "FAILED", "session ended and no new login", ""
                        break
                    page = pg
                except Exception as e:
                    status, msg, shot = "FAILED", str(e).splitlines()[0][:300], ""
                    try:
                        shot = f"{u['id']}_error.png"
                        page.screenshot(path=str(shots / shot))
                    except Exception:
                        pass
                    break
            w.writerow({"time_utc": utcnow().isoformat(), "user_id": u["id"], "username": u["username"],
                        "status": status, "message": msg, "screenshot": shot})
            fh.flush()
            counts[status] += 1
            log(f"  {status}: {msg}")
            fails_in_a_row = fails_in_a_row + 1 if status == "FAILED" else 0
            if fails_in_a_row >= MAX_CONSECUTIVE_FAILURES:
                log(f"STOPPED after {fails_in_a_row} failures in a row. Re-running skips users already reset.")
                break
            page.wait_for_timeout(a.pause * 1000)
        ctx.close()
    log(f"done in {int(time.time() - started)} s: {dict(counts)} -> {results_path}")


# ---------------------------------------------------------------- verify / open-browser

def audit_user_ids(audit_rows):
    """{15-char user Id: first audit row} from SetupAuditTrail 'resetpassword' rows."""
    by_id = {}
    for r in audit_rows:
        m = re.search(r"UserID: \[(\w{15})", r.get("Display") or "")
        if m:
            by_id.setdefault(m.group(1), r)
    return by_id


def verdicts(plan, results, audit_rows):
    by_id = audit_user_ids(audit_rows)
    last = {r["user_id"]: r for r in results}
    rows, c = [], Counter()
    for u in plan["users"]:
        r = last.get(u["id"], {})
        hit = by_id.get(u["id"][:15])
        verdict = ("OK" if r.get("status") == "RESET" and hit else
                   "IN AUDIT ONLY" if hit else
                   "SCRIPT SAID RESET, NOT IN AUDIT" if r.get("status") == "RESET" else
                   "NOT RESET")
        c[verdict] += 1
        rows.append([u["username"], u["id"], r.get("status", "not run"), r.get("message", ""),
                     hit["CreatedDate"] if hit else "", (hit.get("CreatedBy") or {}).get("Username", "") if hit else "",
                     verdict])
    plan_ids = {u["id"][:15] for u in plan["users"]}
    extra = [r for k, r in by_id.items() if k not in plan_ids]
    return rows, c, extra


def cmd_verify(a):
    plan_path = Path(a.plan)
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    results = read_results(plan_path.with_name("results.csv"))
    if not results:
        sys.exit("no results.csv next to the plan")
    since = min(r["time_utc"] for r in results)[:19]
    since = (dt.datetime.fromisoformat(since) - dt.timedelta(minutes=5)).strftime("%Y-%m-%dT%H:%M:%SZ")
    org = a.target_org or plan["org_alias"]
    audit = soql(org, "SELECT CreatedDate, Display, CreatedBy.Username FROM SetupAuditTrail "
                      f"WHERE Action = 'resetpassword' AND CreatedDate >= {since} ORDER BY CreatedDate")
    rows, c, extra = verdicts(plan, results, audit)
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Verify"
    ws.append(["username", "user_id", "script status", "script message", "audit time (UTC)", "audit by", "verdict"])
    for row in rows:
        ws.append(row)
    ws2 = wb.create_sheet("Resets not in plan")
    ws2.append(["audit time (UTC)", "by", "display"])
    for r in extra:
        ws2.append([r["CreatedDate"], (r.get("CreatedBy") or {}).get("Username", ""), r["Display"]])
    out = plan_path.with_name("verify.xlsx")
    wb.save(out)
    log(f"audit trail since {since}: {len(audit)} resets; plan verdicts {dict(c)}; "
        f"{len(extra)} resets of users outside the plan -> {out}")


def cmd_open_browser(a):
    from playwright.sync_api import sync_playwright
    url = a.url
    if a.plan:
        plan = json.loads(Path(a.plan).read_text(encoding="utf-8"))
        url = plan.get("login_url") or plan["base_url"]
    with sync_playwright() as p:
        ctx, page = launch(p)
        page.goto(url)
        log("Browser open. Close the window when you are done.")
        try:
            page.wait_for_event("close", timeout=0)
        except Exception:
            pass
        ctx.close()


def build_parser():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--profile-dir", type=Path, default=DEFAULT_PROFILE_DIR,
                    help=f"browser profile folder (keeps your login between runs; default {DEFAULT_PROFILE_DIR})")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("preflight", help="read-only checks; writes plan.json and preflight.xlsx")
    s.add_argument("--users", required=True, help="user list: .xlsx/.xlsm or .csv with a 'Username' column, or .txt")
    s.add_argument("--sheet", help="worksheet name (default: the first)")
    s.add_argument("-o", "--target-org", help="sf alias or username (default: the sf default org)")
    s.add_argument("--login-url", help="page to log in at during `run`, e.g. https://test.salesforce.com "
                                       "(default: the org's My Domain URL)")
    s.add_argument("--out", required=True, help="folder for plan.json, preflight.xlsx and the results")
    s = sub.add_parser("run", help="click Reset Password for each user in the plan")
    s.add_argument("--plan", required=True)
    s.add_argument("--dry-run", action="store_true", help="open and check each user page, click nothing")
    s.add_argument("--limit", type=int, help="only the first N users not yet reset (pilot)")
    s.add_argument("--confirm", type=int, help="must equal the number of users this run will reset")
    s.add_argument("--prod", action="store_true", help="required when the plan targets a production org")
    s.add_argument("--pause", type=float, default=1.0, help="seconds between users")
    s.add_argument("--login-timeout", type=int, default=900, help="seconds to wait for you to log in")
    s.add_argument("--login-url", help="override the plan's login URL")
    s = sub.add_parser("verify", help="read-only: compare results.csv with the Setup Audit Trail")
    s.add_argument("--plan", required=True)
    s.add_argument("-o", "--target-org", help="override the org alias stored in the plan")
    s = sub.add_parser("open-browser", help="open the script's browser profile (e.g. to log in ahead of time)")
    s.add_argument("--plan")
    s.add_argument("--url", default="https://login.salesforce.com")
    return ap


def main(argv=None):
    global PROFILE_DIR
    a = build_parser().parse_args(argv)
    PROFILE_DIR = a.profile_dir.expanduser()
    {"preflight": cmd_preflight, "run": cmd_run, "verify": cmd_verify, "open-browser": cmd_open_browser}[a.cmd](a)


if __name__ == "__main__":
    main()
