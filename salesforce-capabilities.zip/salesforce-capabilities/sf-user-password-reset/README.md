# sf-user-password-reset

Reset passwords for a list of Salesforce users through the Setup UI, with a read-only preflight,
a dry run, a confirm-count safeguard, and verification against the Setup Audit Trail.

## What it does

`scripts/reset_passwords.py` has four commands:

| Command | Writes to the org? | What it does |
|---|---|---|
| `preflight` | No | Reads the user list, looks up every user, decides READY or SKIP, writes `plan.json` and `preflight.xlsx`. |
| `run` | **Yes** (only this one) | Opens a browser, waits for you to log in, then for each READY user opens the classic Setup user page, checks the username shown, clicks **Reset Password**, accepts only the expected confirmation, and waits for Salesforce's success message. Writes `results.csv` and a screenshot per reset. |
| `verify` | No | Reads the Setup Audit Trail (`resetpassword` entries) and matches it against `results.csv`. Writes `verify.xlsx`. |
| `open-browser` | No | Opens the script's browser profile, for example to log in ahead of time. |

Salesforce sends each user its standard reset email. The script never sees or sets a password.

### Safeguards

- **Preflight is read-only.** A user is skipped if: not found, inactive, frozen, your own login,
  email blank or ending in `.invalid`, duplicated in the list, or the list's `Id` column does not
  match the org. Notes (not skips): locked out, has a Federation ID (SSO), profile changed,
  shared email, never logged in. It also checks that you hold "Reset User Passwords".
- **`run --dry-run`** opens every page and checks it, but clicks nothing.
- **`--confirm N`** must equal the number of users this run will reset, or nothing starts.
- **`--prod`** is required when the plan's org is production (from `Organization.IsSandbox`).
- **The list is fingerprinted.** If the user-list file changes after preflight, `run` refuses.
- **Username check on every page.** If the page shows a different username, it does not click.
- **Unexpected confirmation text is dismissed**, and the user is marked FAILED.
- **Stops after 3 failures in a row.**
- **Resumable.** Users already marked RESET in `results.csv` are never reset twice; `--confirm`
  counts only the remaining users.
- **`verify`** shows users the script reset that are missing from the audit trail, and resets
  in the same window of users not in the plan.

## Prerequisites

- Python 3.10+
- `openpyxl` and `playwright` (`requirements.txt`), plus Playwright's Chromium:
  ```
  python -m pip install -r requirements.txt
  python -m playwright install chromium
  ```
  Playwright drives a real Chromium window. You log in to Salesforce in that window yourself
  (password, MFA, SSO all work); the script never handles credentials.
- Salesforce CLI v2 (`sf`), logged in to the org, for `preflight` and `verify`:
  `sf org login web --alias my-sandbox`
- Your user needs "Reset User Passwords" (and "View Setup and Configuration" to read the audit
  trail).

## Quick start

```
python scripts/reset_passwords.py preflight --users examples/users_example.csv --target-org my-sandbox --out runs/reset1
# review runs/reset1/preflight.xlsx
python scripts/reset_passwords.py run --plan runs/reset1/plan.json --dry-run
python scripts/reset_passwords.py run --plan runs/reset1/plan.json --limit 1 --confirm 1      # pilot
python scripts/reset_passwords.py run --plan runs/reset1/plan.json --confirm <remaining N>
python scripts/reset_passwords.py verify --plan runs/reset1/plan.json
```

## Usage

Global option: `--profile-dir DIR` (browser profile; default `~/.sf-password-reset-browser`).
Keep the profile private: it holds your Salesforce session cookies.

### preflight

| Option | Meaning |
|---|---|
| `--users FILE` | `.xlsx`/`.xlsm` or `.csv` with a `Username` column (the header row can be below title rows), or `.txt` with one username per line. Optional columns: `Id`, `Profile.Name` (or `Profile`). |
| `--sheet NAME` | Worksheet (default: the first). |
| `-o`, `--target-org` | sf alias or username. Default: the sf default org. |
| `--login-url URL` | Where `run` opens the login page, e.g. `https://test.salesforce.com` or `https://login.salesforce.com`. Default: the org's My Domain URL. |
| `--out DIR` | Folder for `plan.json`, `preflight.xlsx`, and later `results.csv`, `screenshots/`, `verify.xlsx`. |

### run

| Option | Meaning |
|---|---|
| `--plan FILE` | The `plan.json` from preflight. |
| `--dry-run` | Check every page, click nothing. Writes `results_dryrun.csv`. |
| `--limit N` | Only the first N users not yet reset (pilot). |
| `--confirm N` | Must equal the number of users this run resets. |
| `--prod` | Required for a production org. |
| `--pause S` | Seconds between users (default 1). |
| `--login-timeout S` | Seconds to wait for your login (default 900). |
| `--login-url URL` | Override the plan's login URL. |

### verify

`--plan FILE`, optional `-o/--target-org` to override the alias stored in the plan.

### open-browser

`--plan FILE` (opens its login URL) or `--url URL`.

## Tests

```
python tests/run_tests.py          # all tests; browser tests skip if Chromium is missing
python tests/run_tests.py --unit   # unit tests only
```

The browser tests run `run` against a fake classic user page on localhost: dry run, wrong
username, unexpected dialog, missing button, 3-failure stop, resume, `--limit`, lost session,
late login (same tab and new tab), and an empty `results.csv`. No org is called.

## Safety notes

- Run `preflight` and a `--dry-run` first, and a `--limit 1` pilot on a sandbox.
- Get approval before a production run; `--prod` is a deliberate extra step, not a formality.
- The output folder holds usernames and emails. Do not commit it (`.gitignore` covers `runs/`).
- Users with SSO (Federation ID) may never use a Salesforce password; preflight flags them.

## Limitations

- It drives the classic Setup user page (`/<userId>?noredirect=1&isUserEntityOverride=1`) and
  the English texts "Reset Password", "Reset password for this user?" and the success message.
  Run it as a user whose language is English. If Salesforce changes that page, `--dry-run` will
  fail first.
- One user at a time, about 5-10 seconds each.
- The audit trail match uses the 15-character user Id inside the audit `Display` text.
